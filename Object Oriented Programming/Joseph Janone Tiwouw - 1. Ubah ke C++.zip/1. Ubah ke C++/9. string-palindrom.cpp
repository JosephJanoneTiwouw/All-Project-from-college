#include <stdio.h>
#include <conio.h>
#include <string.h>

void balikan(char kalimat[]){
	strrev(kalimat);
	puts(kalimat);
}

void hitungKarakter(char kalimat[]){
	int jumlahKata;
	jumlahKata = strlen(kalimat);
	printf("%d",jumlahKata);
}

int main()
{
  char kalimat[50];
  
  printf("Masukan kata atau kalimat : ");
  gets(kalimat);
  balikan(kalimat);
  
  getch();
  return 0;
}



#include <stdio.h>
#include <conio.h>

int main()
{
	int jlhOrang,kelas,Total;

    printf(" UK TRAVEL\n ");
    printf("-------------------------------------\n ");

	printf("Berapa orang yang akan berangkat? ");
	scanf("%d",&jlhOrang);
	printf("Silahkan masukan pilihan anda\n 1.VIP\n 2.Bussiness\n 3.Ekonomi \n Silahkan masukan pilihan anda! ");
	scanf("%d",&kelas);
	if(kelas==1){
		Total = jlhOrang * 2200000;
		printf("Total biaya tiket =  %d",Total);
	}
	else if(kelas==2){
		Total = jlhOrang * 1800000;
		printf("Total biaya tiket =  %d",Total);
	}
	else if(kelas==3){
		Total = jlhOrang * 1500000;
		printf("Total biaya tiket =  %d",Total);
	}
	else{
		printf("Maaf, salah masukan angka",Total);
	}

	getch();
	return 0;
}

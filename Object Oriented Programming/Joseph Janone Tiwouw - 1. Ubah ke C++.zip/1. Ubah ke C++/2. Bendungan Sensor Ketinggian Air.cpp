/* Dsc: jawaban soal no 1
   Date: 03/03/2016
   Author: Andy
   Version: 1.0
*/
//load library
#include<conio.h>
#include<stdio.h>

int main(){
  //deklarasi variable
   int tinggi_air;
   //input tinggi air
   printf("masukan tinggi air");
   scanf("%d",&tinggi_air);
   
   //process
   if(tinggi_air < 5){//jika tinggi air < 5 meter
		printf("kekurangan suplai air");
   }else if(tinggi_air >= 6 && tinggi_air <= 10){//jika tinggi air > 6 meter dan < 10 meter
		printf("Ketinggian air normal");
   }else if(tinggi_air >= 11 && tinggi_air <= 15){//jika tinggi air > 6 meter dan < 10 meter
		printf("Di atas rata rata");
   }else if(tinggi_air >= 16 && tinggi_air <= 20){//jika tinggi air > 6 meter dan < 10 meter
		printf("Waspada");
   }else if(tinggi_air >= 21 && tinggi_air <= 30){//jika tinggi air > 6 meter dan < 10 meter
		printf("pintu palka dibuka");
   }else {
		printf("Evakuasi");
   }

  getche();
  return 0;
}

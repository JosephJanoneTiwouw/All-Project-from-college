#include <stdio.h>
#include <conio.h>
#include <string.h>

int main()
{
  char kalimat[50]="haloo";
  int hurufHidup=0, hurufKecil=0, hurufBesar=0,i;
  
  printf("Masukan kalimat : ");
  gets(kalimat);

  for(i=0; kalimat[i]!='\0' ;i++){
		if(kalimat[i]=='a' || kalimat[i]=='i' || kalimat[i]=='u' || kalimat[i]=='e' || kalimat[i]=='o' || kalimat[i]=='A' || kalimat[i]=='I' || kalimat[i]=='U' || kalimat[i]=='E' || kalimat[i]=='O'){
			hurufHidup++;
		}
		if(kalimat[i]>='a' && kalimat[i]<='z'){
			hurufKecil++;
		}
		if(kalimat[i]>='A' && kalimat[i]<='Z'){
			hurufBesar++;
		}
  }
  printf("Jumlah huruf Hidup = %d",hurufHidup);
  printf("\nJumlah huruf Kecil = %d",hurufKecil);
  printf("\nJumlah huruf besar = %d",hurufBesar);
  
  getch();
  return 0;
}

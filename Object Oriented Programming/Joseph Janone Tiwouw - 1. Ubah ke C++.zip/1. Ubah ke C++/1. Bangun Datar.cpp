#include<stdio.h>
#include<conio.h>
#include<windows.h>

int main()
{
 int pilih, sisi, panjang, lebar, keliling, luas, rusuk, luasPermukaanKubus;
 float jariJari, luasLing, kelilingLing,  luasSatuSisi, volumeKubus;
 pilih = 0;
 do{
    //system("cls");
    printf("\n===============================\n");
    printf("PROGRAM MENGHITUNG BANGUN DATAR\n===============================\n");
	printf("1. Persegi\n");
	printf("2. Persegi Panjang\n");
	printf("3. Exit\n");
	printf("\nMasukan pilihan: ");
	scanf("%d",&pilih);
	switch(pilih){
		case 1:
		  //input
		  //system("cls");
		  printf("PERSEGI\n");
		  printf("===============================\n");
		  printf("Masukan sisi Kubus : ");  scanf("%d",&sisi);
		  //process  -  rumus hitung luas dan keliling
    	  luas= sisi * sisi;
		  keliling = 4 * sisi;
		  //output - display
    	  printf("\nLuas Permukaan = %d",luas);
		  printf("\nKeliling = %d",keliling);
		  printf("\n\n");
		  break;
		
		case 2:
		  //input
          //system("cls");
          printf("PERSEGI PANJANG\n");
           printf("===============================\n");
		  printf("Masukan panjang : ");  scanf("%d",&panjang);
		  printf("Masukan lebar : ");  scanf("%d",&lebar);
		  //proses
		  luas = panjang * lebar;
		  keliling = 2 * (panjang + lebar) ;
          //output
		  printf("\nLuasPermukaan = %d", luas);
		  printf("\nKeliling = %d",keliling);
		  printf("\n\n");
		  break;
	}
  } while(pilih != 3);
    //system("cls");
    printf("TERIMA KASIH\n");

	
 getch();
 return 0;
}

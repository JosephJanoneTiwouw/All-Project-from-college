#include <stdio.h>
#include <conio.h>
#include <string.h>

int main()
{
  char kalimat[50]="haloo";
  int hurufHidup=0, hurufKecil=0, hurufBesar=0,i;
  
  printf("Masukan kalimat : ");
  gets(kalimat);

  for(i=0; kalimat[i]!='\0' ;i++){
		if(kalimat[i]>='a' && kalimat[i]<='z'){
			hurufKecil++;
		}
		if(kalimat[i]>='A' && kalimat[i]<='Z'){
			hurufBesar++;
		}
  }
  printf("\nJumlah huruf Kecil = %d",hurufKecil);
  printf("\nJumlah huruf besar = %d",hurufBesar);
  
  
  
  
  getch();
  return 0;
}

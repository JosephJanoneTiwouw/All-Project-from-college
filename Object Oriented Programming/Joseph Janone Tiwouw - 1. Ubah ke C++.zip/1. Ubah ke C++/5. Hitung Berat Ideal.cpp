/*
Desc: program menghitung berat badan
Author: And

*/
#include<stdio.h>
#include<conio.h>
int main(){
	int berat_ideal,berat_badan,tinggi_badan,berat_saran;
	//input tinggi badan dan berat
	printf("PROGRAM MENGHITUNG BERAT BADAN IDEAL\n");
    printf("____________________________________\n");
	printf("masukan tinggi badan anda: ");
	scanf("%d",&tinggi_badan);
	printf("masukan berat badan anda: ");
	scanf("%d",&berat_badan);
	
	//prosess hitung berat ideal
	berat_ideal = tinggi_badan - 102;
	
	//prosses dan output
	printf("\n\nberat ideal anda adalah: %d kg\n", berat_ideal);
	if(berat_ideal < berat_badan ){
		berat_saran = berat_badan - berat_ideal;
		printf("kurangi berat: %d kg",berat_saran);
	}
	else if(berat_ideal > berat_badan ){
        berat_saran = berat_ideal - berat_badan;
		printf("tambah berat: %d kg",berat_saran);
	}
	else{
        printf("anda memiliki berat badan ideal");
	}
	getch();
}

#include <stdio.h>
#include <conio.h>
int main()
{
  int num=5,baris,bintang,spasi;

	for(baris=1; 5>=baris; baris++)
 	{
  		for(spasi=5-baris; spasi>=1; spasi--){
			printf("@");
		}
    	for(bintang=1; bintang<=baris; bintang++){
    		 printf("*");
	    }
  		printf("\n");
 	}
 	for(baris=1; 5>=baris; baris++)
 	{
  		for(spasi=5-baris; spasi>=1; spasi--){
			printf("*");
		}
    	for(bintang=1; bintang<=baris; bintang++){
    		 printf("@");
	    }
  		printf("\n");
 	}

  getch();
  return 0;
}

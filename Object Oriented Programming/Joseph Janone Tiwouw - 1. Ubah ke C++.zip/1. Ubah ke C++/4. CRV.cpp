/* Author: Andria
   Desc  : Simple Big Letter Alphabetical Function using Void
   Date  : 20/1/06
   Version: 1.0
*/
#include<stdio.h>
#include<conio.h>

//function definition
void hurufC(){
	printf("CCCCCCCCC\n");
	printf("C\n");
	printf("C\n");
	printf("C\n");
	printf("CCCCCCCCC\n\n");
}

void hurufR(){
	printf("RRRRRRRRR\n");
	printf("R       R\n");
	printf("RRRRRRRRR\n");
	printf("R     R\n");
	printf("R      R\n\n");
}

void hurufV(){
	printf("V       V\n");
	printf(" V     V\n");
	printf("  V   V\n");
	printf("   V V\n");
	printf("    V\n\n\n");
}

int main(){
    //function call
    hurufC();
	hurufR();
	hurufV();
	getch();
}

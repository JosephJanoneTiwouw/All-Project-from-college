/* Desc: Jawaban soal no 2
   file name: soal.cpp
   author: UK Lecture
   date: 03/03/16
*/
//include library
#include <stdio.h>
#include <conio.h>

int main()
{
	//deklarasi
	long biaya=0,total=0;

	//input harga barang
	printf("masukan harga :");
	scanf("%d",&biaya);

	//proses & output
	if(biaya <= 5000000){//jika biaya < 5jt
	    total = biaya + (biaya * 0.1);
		printf("%d",total);
	}
	else if(biaya >= 6000000 && biaya <= 10000000){ //jika biaya >= 6jt dan biaya <= 10jt
	    total = biaya + (biaya * 0.2);
		printf("%d",total);
	}
	else if(biaya >= 11000000 && biaya <= 20000000){ //jika biaya >= 11jt dan biaya <= 20jt
		total = biaya + (biaya * 0.3);
		printf("%d",total);
	}
	else if(biaya > 20000000){ //jika biaya >20jt
		total = biaya + (biaya * 0.5);
		printf("%d",total);
	}
	else {
		printf("masukan nilai bukan minus");
	}

	//tahan display layar
	getch();
	return 0;
}
